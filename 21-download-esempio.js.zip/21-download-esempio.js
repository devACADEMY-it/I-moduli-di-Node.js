/*
 * I moduli di Node.js
 * Scaricare file
 *
 * Disponibile su devACADEMY.it
 */

const fs= require('fs')
const https=require('https')
const file=fs.createWriteStream('canguro.jpg')
const url='https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Kangaroo_and_joey05.jpg/300px-Kangaroo_and_joey05.jpg'

https.get(url, (response) => {
	response.pipe(file)
})