/*
 * I moduli di Node.js
 * Lettura asincrona di file
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')
function letturaEseguita(err,data){
	if (err)
		console.log("Il file non esiste")
	else
		console.log(data)
}

fs.readFile('testo.txt', 'utf-8', letturaEseguita)