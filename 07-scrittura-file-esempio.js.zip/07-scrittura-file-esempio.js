/*
 * I moduli di Node.js
 * Scrivere su file
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')

messaggio='Un altro contenuto...salvato in modo sincrono'

try {
	fs.writeFileSync('salvataggio_dati.txt', messaggio)
	console.log('Salvataggio completo!')
}
catch(err){
	console.log('Errore!')
}

/*fs.writeFile('salvataggio_dati.txt', messaggio,
 (err) => {
	 if (err){
		 console.log('Errore')
	 }
	 else
	 {
		 console.log('Salvataggio completo!')
	 }
 })*/