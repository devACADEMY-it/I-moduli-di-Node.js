/*
 * I moduli di Node.js
 * Stream in lettura
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')

const rs=fs.createReadStream('documento.pdf',
                               {highWaterMark: 8*1024})
totale_letto = 0

rs.on('data', (chunk) =>{
	totale_letto += chunk.length
	console.log(`Ho letto ${chunk.length} byte di dati`)
})