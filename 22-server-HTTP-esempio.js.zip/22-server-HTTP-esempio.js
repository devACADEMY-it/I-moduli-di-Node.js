/*
 * I moduli di Node.js
 * Creare un server HTTP
 *
 * Disponibile su devACADEMY.it
 */

const http = require('http')

const server = http.createServer(
	(req, res) =>{
		res.writeHead(200)
		res.end('<h1>Il nostro server RISPONDE...</h1>')
	}).listen()

console.log(server.address().port)