/*
 * I moduli di Node.js
 * Cancellare file
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')

try {
	fs.unlinkSync('dati.txt')
	console.log('Cancellazione eseguita')
}
catch(err){
	console.log('Errore')
}

/*fs.unlink('dati.txt', (err) => {
	if (err)
		console.log('Errore')
	else
		console.log('Cancellazione eseguita')
})*/