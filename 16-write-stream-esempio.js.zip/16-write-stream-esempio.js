/*
 * I moduli di Node.js
 * Stream in scrittura
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')

const nomi=['Simone', 'Alessio', 'Agata', 'Paolo']
const cognomi=['Rossi', 'Bianchi', 'Neri', 'Marroni']

function personaCasuale(){
	nome=nomi[Math.floor(Math.random()*nomi.length)]
	cognome=cognomi[Math.floor(Math.random()*cognomi.length)]

	eta=Math.floor(Math.random()*50)+18
	return `${nome} ${cognome} (${eta} anni)\n`
}

const ws=fs.createWriteStream('output.txt')
for (i=0;i<50;i++)
	ws.write(personaCasuale())
ws.end('THE END')