/*
 * I moduli di Node.js
 * Analisi dei dati
 *
 * Disponibile su devACADEMY.it
 */

const request=require('request')

function analizzaDati(prezzi){
	iniziale=prezzi[0]
	max=iniziale
	min=iniziale
	finale=prezzi[prezzi.length-1]

	for (i=1; i<prezzi.length; i++){
		if (prezzi[i]>max)
			max=prezzi[i]
		else if (prezzi[i]<min)
			min=prezzi[i]
	}
	console.log(`Prezzi iniziale ${iniziale}`)
	console.log(`Prezzi massimo ${max}`)
	console.log(`Prezzi minimo ${min}`)
	console.log(`Prezzi finale ${finale}`)

}

request('http://localhost:8080?t=20&n=ABC',
	(error, response, body) => {
		if (error==null){
			if (response && response.statusCode==200){
				console.log("BODY:")
				console.log(body)
				console.log()

				var prezzi=[]
				for (x of body.split('\n')){
					//  ABC	34
					valore=x.split('\t')[1]
					prezzi.push(parseInt(valore))
				}
				console.log("DATI:")
				console.log(prezzi)
				console.log()
				console.log("STATISTICHE:")
				analizzaDati(prezzi)
			}
			else
				console.log("Richiesta non valida")

		}
		else
			console.log("Errore di connessione")

	}
)