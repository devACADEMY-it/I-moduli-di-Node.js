/*
 * I moduli di Node.js
 * Log e callback in un server web
 *
 * Disponibile su devACADEMY.it
 */

const http = require('http')

function avviato(){
	console.log('Il server è stato avviato...')
}

http.createServer(
	(req, res) =>{
		console.log('Ricevuta una richiesta...')
		res.writeHead(200)
		res.end('<h1>Il nostro server RISPONDE...</h1>')
	}).listen('8080', avviato)