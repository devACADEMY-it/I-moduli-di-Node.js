/*
 * I moduli di Node.js
 * Lavorare con le cartelle
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')
const os=require('os')
const path=require('path')
const rimraf=require('rimraf')

/*
PASSO 1: creazione di una cartella con file
PASSO 2: ridenominazione della cartella
PASSO 3: stampa del contenuto
PASSO 4: cancellazione della cartella (non vuota)
*/

const cartella_da_creare='nuova_cartella'
const nome_file='messaggio.txt'
const testo_file='Ecco il messaggio da salvare'
const cartella_rinominata='cartella_rinominata'

function creazioneFile(){
	console.log(`PASSO 1 ... creata la cartella ${cartella_da_creare}`)
	fs.writeFile(`${cartella_da_creare}${path.sep}${nome_file}`,
	 testo_file, operazioniSuCartella)
}

function operazioniSuCartella(err){
	if(err)
		return
	fs.rename(cartella_da_creare, cartella_rinominata, (err) =>{
		if (!err){
			console.log(`PASSO 2 ... ${cartella_da_creare} rinominata in ${cartella_rinominata}`)
		    fs.readdir(cartella_rinominata, (errore, files)=>{
				if(!errore){
					console.log(`PASSO 3 ... contenuto di ${cartella_rinominata}`)
					for(c of files)
						console.log("  "+c)
					rimraf(cartella_rinominata, (err) => {
						if(!err){
							console.log("PASSO 4 ... cancellazione avvenuta con successo")
						}
					})
				}
			})
		}
	})

}

// creazione cartella (asincrona)
fs.mkdir(cartella_da_creare, creazioneFile)