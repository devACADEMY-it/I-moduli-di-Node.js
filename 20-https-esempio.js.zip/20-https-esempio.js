/*
 * I moduli di Node.js
 * HTTPS lato client
 *
 * Disponibile su devACADEMY.it
 */

const https = require('https')
const options={
	hostname: 'it.wikipedia.org',
	method: 'GET',
	path: '/wiki/Macropodidae'
}

const request = https.request(options,
 (response) => {
	 if (response.statusCode<300 && response.statusCode>=200)
		 response.on('data', (y) => {
			 process.stdout.write(y)
		 })
	 else
		 console.log(response.statusCode)
 })
 .on('error', (e) => {
	 console.log(`Errore codice ${e.code}`)
 }).end()