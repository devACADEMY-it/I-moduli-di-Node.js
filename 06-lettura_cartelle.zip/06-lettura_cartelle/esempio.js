/*
 * I moduli di Node.js
 * Lettura di cartelle
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')

dir='.\\archivio'

fs.readdir(dir, (err, files) => {
	if (err){
		console.log(err)
	}
	else{
		for (c of files){
			stat=fs.statSync(dir+'\\'+c)
			if (stat.isDirectory())
				console.log(`(dir) ${c}`)
			else
				console.log(`${c} (${stat.size} bytes)`)
		}
	}
})