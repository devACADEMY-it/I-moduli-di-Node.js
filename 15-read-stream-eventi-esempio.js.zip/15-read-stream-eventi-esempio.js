/*
 * I moduli di Node.js
 * Stream ulteriori eventi
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')

const rs=fs.createReadStream('documento.pdf',
                               {highWaterMark: 8*1024})
totale_letto = 0
contatore=0

rs.on('data', (chunk) =>{
	totale_letto += chunk.length
	contatore += chunk.length
	console.log(`Ho letto ${chunk.length} byte di dati`)
	if (contatore>60000)
		rs.pause()

})
.on('pause', function(){
	console.log('Pausa...')
	rs.resume()
	contatore=0
})
.on('end', function(){
	console.log(`Finito ... in totale ho letto ${totale_letto}`)
})