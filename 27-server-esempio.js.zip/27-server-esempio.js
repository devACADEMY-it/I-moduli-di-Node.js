/*
 * I moduli di Node.js
 * Preparazione del server
 *
 * Disponibile su devACADEMY.it
 */

const url = require('url')
const http = require('http')

function creaPrezzo(precedente){
	valore=Math.round(precedente+(Math.random()*10-5))
	return valore>0?valore:1
}

function caricaDati(res, nome, t)
{
	var nuovoPrezzo=Math.round(Math.random()*50+20)
	for (i=0;i<t-1;i++){
		nuovoPrezzo=creaPrezzo(nuovoPrezzo)
		res.write(`${nome}\t${nuovoPrezzo}\n`)
	}
	nuovoPrezzo=creaPrezzo(nuovoPrezzo)
	res.end(`${nome}\t${nuovoPrezzo}`)

}

const server = http.createServer(
	(req, res) =>{
		// http://localhost:8080?t=20&n=ABC
		query=url.parse(req.url,true).query
		if (query.t!=undefined &&
					query.n!=undefined )
		{
			res.writeHead(200)
			caricaDati(res, query.n, query.t)
		}
		else
		{
			res.writeHead(400)
			res.end()
		}
	}).listen(8080)
console.log(`Server avviato sulla porta ${server.address().port}`)