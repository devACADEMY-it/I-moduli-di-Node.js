/*
 * I moduli di Node.js
 * Richiesta dei dati via HTTP
 *
 * Disponibile su devACADEMY.it
 */

const request=require('request')

request('http://localhost:8080?ta=20&n=ABC',
	(error, response, body) => {
		if (error==null){
			if (response && response.statusCode==200){
				console.log("BODY:")
				console.log(body)
			}
			else
				console.log("Richiesta non valida")

		}
		else
			console.log("Errore di connessione")

	}
)