/*
 * I moduli di Node.js
 * Aggiornamento di file
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')

messaggio = 'ultima riga aggiunta'

fs.appendFile('dati.txt', messaggio, (err) => {
	if (err)
		console.log("Errore!")
	else
		console.log('Scrittura completata!!')
})