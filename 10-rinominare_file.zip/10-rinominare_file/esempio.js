/*
 * I moduli di Node.js
 * Rinominare file
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')

const damodificare='dati.txt'
const nuovonome='nuovo_nome.txt'

try {
	fs.renameSync(damodificare, nuovonome)
	console.log('File rinominato')
}
catch(err){
	console.log('Errore!')
}

/*fs.rename(damodificare, nuovonome, (err) => {
	if (err)
		console.log('Errore')
	else
		console.log('File rinominato')
})*/