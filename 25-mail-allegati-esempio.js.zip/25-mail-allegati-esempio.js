/*
 * I moduli di Node.js
 * Inviare mail con allegati
 *
 * Disponibile su devACADEMY.it
 */

const mailer=require('nodemailer')

const transport = mailer.createTransport(
	{
		service: 'gmail',
		auth: {
			user: 'nodemail01@gmail.com',
			pass: 'scoiattolo'
		}
	}
)

const options = {
		to: 'nodemail02@gmail.com',
		subject: 'Mail con due allegati',
		text: 'Ciao, come va? Ecco i file che ti interessano',
		attachments: [
			{
				path: './canguro.jpg'
			},
			{
				path: './incassi.csv'
			}
		]
}

transport.sendMail(options, (err, data) =>{
		if (err)
			console.log(err.response)
		else
			console.log(`Invio riuscito: ${data.response}`)
})