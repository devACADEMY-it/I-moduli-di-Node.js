/*
 * I moduli di Node.js
 * Inviare mail
 *
 * Disponibile su devACADEMY.it
 */

const mailer=require('nodemailer')

const transport = mailer.createTransport(
	{
		service: 'gmail',
		auth: {
			user: 'nodemail01@gmail.com',
			pass: 'scoiattolo'
		}
	}
)

const options = {
		to: 'nodemail02@gmail.com',
		subject: 'come stai?',
		text: 'Ciao, come va? Puoi dirmi se il messaggio arriva?'
}

transport.sendMail(options, (err, data) =>{
		if (err)
			console.log(err.response)
		else
			console.log(`Invio riuscito: ${data.response}`)
})