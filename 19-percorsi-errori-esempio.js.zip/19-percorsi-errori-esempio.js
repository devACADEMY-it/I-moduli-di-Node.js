/*
 * I moduli di Node.js
 * Gestione di percorsi web ed errori
 *
 * Disponibile su devACADEMY.it
 */

const http = require('http')
const options={
	hostname: 'info.cern.ch',
	method: 'GET',
	path: '/hypertext/WWW/paginachenonesiste.html'
}

const request = http.request(options,
 (response) => {
	 if (response.statusCode<300 && response.statusCode>=200)
		 response.on('data', (y) => {
			 process.stdout.write(y)
		 })
	 else
		 console.log(response.statusCode)
 })
 .on('error', (e) => {
	 console.log(`Errore codice ${e.code}`)
 }).end()