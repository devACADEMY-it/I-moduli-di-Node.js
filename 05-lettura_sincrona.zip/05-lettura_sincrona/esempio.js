/*
 * I moduli di Node.js
 * Lettura sincrona di file
 *
 * Disponibile su devACADEMY.it
 */

const fs=require('fs')

try {
 data=fs.readFileSync('testo.txt', 'utf-8')
 console.log(data)
}
catch(err)
{
  console.log(err.path)
}